import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import BuscarCedula from "./BuscarCedula";
import DetallePersona from "./DetallePersona";
import MiembrosEquipo from "./MiembrosEquipo";
import MapaUbicacion from "./MapaUbicacion";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<BuscarCedula />} />
        <Route path="/persona/:cedula" element={<DetallePersona />} />
        <Route path="/equipo/:equipoId" element={<MiembrosEquipo />} />
        <Route path="/mapa/:personaId" element={<MapaUbicacion />} />
      </Routes>
    </Router>
  );
}

export default App;