import React from "react";
import { useParams, useNavigate } from "react-router-dom";

// Finge datos de equipo
const equipos = {
  equipo1: [
    { id: "1", nombre: "Juan Pérez" },
    { id: "2", nombre: "Ana López" }
  ]
};

function MiembrosEquipo() {
  const { equipoId } = useParams();
  const navigate = useNavigate();
  const miembros = equipos[equipoId] || [];

  return (
    <div>
      <h2>Miembros del equipo</h2>
      <ul>
        {miembros.map(m => (
          <li key={m.id}>
            {m.nombre}{" "}
            <button onClick={() => navigate(`/mapa/${m.id}`)}>
              Ver ubicación
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
export default MiembrosEquipo;