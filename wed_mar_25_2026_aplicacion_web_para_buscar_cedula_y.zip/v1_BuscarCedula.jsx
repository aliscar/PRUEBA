import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function BuscarCedula() {
  const [cedula, setCedula] = useState("");
  const navigate = useNavigate();

  const buscarPersona = async (e) => {
    e.preventDefault();
    // Aquí deberías verificar la existencia de la persona (API)
    navigate(`/persona/${cedula}`);
  };

  return (
    <form onSubmit={buscarPersona}>
      <input
        type="text"
        value={cedula}
        onChange={e => setCedula(e.target.value)}
        placeholder="Ingrese cédula"
        required
      />
      <button type="submit">Buscar</button>
    </form>
  );
}

export default BuscarCedula;