import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";

// Finge API
const fakeApi = {
  "123": { nombre: "Juan Pérez", equipoId: "equipo1" }
};

function DetallePersona() {
  const { cedula } = useParams();
  const [persona, setPersona] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    // Simula una llamada a API
    setPersona(fakeApi[cedula]);
  }, [cedula]);

  if (!persona) return <div>Cargando...</div>;

  return (
    <div>
      <h2>Detalle de {persona.nombre}</h2>
      <button onClick={() => navigate(`/equipo/${persona.equipoId}`)}>
        Ver equipo
      </button>
    </div>
  );
}

export default DetallePersona;