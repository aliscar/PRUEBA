import React from "react";
import { useParams } from "react-router-dom";
import { MapContainer, TileLayer, Marker } from "react-leaflet";
import 'leaflet/dist/leaflet.css';

// Posiciones ficticias
const ubicaciones = {
  "1": { lat: 10.5, lng: -66.9 },
  "2": { lat: 10.6, lng: -66.8 }
};

function MapaUbicacion() {
  const { personaId } = useParams();
  const posicion = ubicaciones[personaId];

  if (!posicion) return <div>Ubicación no encontrada</div>;

  return (
    <MapContainer center={[posicion.lat, posicion.lng]} zoom={13} style={{ height: "400px", width: "100%" }}>
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      <Marker position={[posicion.lat, posicion.lng]} />
    </MapContainer>
  );
}
export default MapaUbicacion;